module ReciptsHelper
end
